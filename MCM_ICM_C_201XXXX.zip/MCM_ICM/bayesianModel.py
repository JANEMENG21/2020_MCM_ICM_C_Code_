import math
from fractions import Fraction

PROPERTY_NUM = 4
property_name = ['outlook', 'temperature', 'humidity', 'wind']

name = [['sunny', 'overcast', 'rain'],
        ['hot', 'mild', 'cool'],
        ['high', 'normal'],
        ['weak', 'strong']]
outlook_num = 3
temperature_num = 3
humidity_num = 2
wind_num = 2

cons_name = ['yes', 'no']
cons_num = 2

sunny = 0
overcast = 10
rain = 20

hot = 1
mild = 11
cool = 21

high = 2
normal = 12

weak = 3
strong = 13

yes = 9
no = 19

property_list = [[sunny, overcast, rain],
                 [hot, mild, cool],
                 [high, normal],
                 [weak, strong]]
cons = [yes, no]

trainSample = [[sunny,hot,high,weak,no],
            [sunny,hot,high,strong,no],
            [overcast,hot,high,weak,yes],
            [rain,mild,high,weak,yes],
            [rain,cool,normal,weak,yes],
            [rain,cool,normal,strong,no],
            [overcast,cool,normal,strong,yes],
            [sunny,mild,high,weak,no],
            [sunny,cool,normal,weak,yes],
            [rain,mild,normal,weak,yes],
            [sunny,mild,normal,strong,yes],
            [overcast,mild,high,strong,yes],
            [overcast,hot,normal,weak,yes],
            [rain,mild,high,strong,no]]

def calc_entropy(list):
    entropy = 0
    total = 0
    for num in list:
        if num != 0:
            total += num
        else:
            return 0

    for num in list:
        entropy -= Fraction(num,total) * math.log(Fraction(num,total), 2)

    return entropy


def calc_gain_part(property_class_list):
    total = 0
    gain_part = 0
    for each_property_list in property_class_list:
        each_total = 0
        for num_cons in each_property_list:
            each_total += num_cons
        entropy = calc_entropy(each_property_list)
        gain_part += each_total * entropy
        total += each_total
    gain_part = gain_part/total
    return gain_part


def subset_judge(list, src):
    if set(list) <= set(src):
        return True
    else:
        return False


def tree(property_stack_list, property_list):
    # property_num_list = [[[0] * cons_num] * outlook_num,
    #                      [[0] * cons_num] * temperature_num,
    #                      [[0] * cons_num] * humidity_num,
    #                      [[0] * cons_num] * wind_num]
    property_num_list = [[[0, 0], [0, 0], [0, 0]], [[0, 0], [0, 0], [0, 0]], [[0, 0], [0, 0]], [[0, 0], [0, 0]]]
    cons_num_list = [0, 0]

    branch_trainSample = []
    gain_list =[]

    for sample in trainSample:
        if subset_judge(property_stack_list, sample):
            branch_trainSample.append(sample)

    for each in branch_trainSample:
        if each[PROPERTY_NUM] == yes:
            cons_num_list[0] += 1
        else:
            cons_num_list[1] += 1

    for train_list in branch_trainSample:
        for i in range(PROPERTY_NUM):
            j = int(train_list[i]/10)
            if train_list[PROPERTY_NUM] == yes:
                property_num_list[i][j][0] = property_num_list[i][j][0] + 1 # pos
            else:
                property_num_list[i][j][1] = property_num_list[i][j][1] + 1 # neg

    entropy_s = calc_entropy(cons_num_list)
    if entropy_s == 0:
        if cons_num_list[0] > 0:
            print('--%s' % cons_name[0])
        else:
            print('--%s' % cons_name[1])
        return 0

    for i in range(len(property_num_list)):
        each_property_list = property_num_list[i]
        for stack in property_stack_list:
            if i == stack%10:
                gain = 0
                break
        else:
            gain_part = calc_gain_part(each_property_list)
            gain = entropy_s - gain_part
        gain_list.append(gain)
    # print(gain_list)

    max_flag = gain_list.index(max(gain_list))
    print('--%s' % property_name[max_flag].upper(), end= '')

    for i in range(len(property_list[max_flag])):
        property_stack_list.append(property_list[max_flag][i])
        print('--%s' % name[max_flag][i], end= '')
        tree(property_stack_list, property_list)
        property_stack_list.pop()



if __name__ == '__main__':
    property_stack_list = []
    tree(property_stack_list, property_list)
    print('Finish!')