import math
from fractions import Fraction
import reorder

PROPERTY_NUM = 7 # manual operation
property_name = ['overall', 'size', 'operation', 'compare', 'degree', 'experience', 'price'] # manual operation
name = [['good', 'bad', 'normal_overall'],
        ['fit', 'small', 'big', 'normal_size'],
        ['easy', 'difficult', 'normal_operation'],
        ['yes', 'no', 'normal_compare'],
        ['much', 'little', 'normal_degree'],
        ['positive', 'negative', 'normal_experience'],
        ['cheap', 'expensive', 'normal_price']]
overall_num = 3 # manual operation
size_num = 4
operation_num = 3
compare_num = 3
degree_num = 3
experience_num = 3
price_num = 3

cons_name = ['high', 'low'] # manual operation
cons_num = 2

good = 0 # manual operation
bad = 10
normal_overall = 20

fit = 1
small = 11
big = 21
normal_size = 31

easy = 2
difficult = 12
normal_operation = 22

yes = 3
no = 13
normal_compare = 23

much = 4
little = 14
normal_degree = 24

positive = 5
negative = 15
normal_experience = 25

cheap = 6
expensive = 16
normal_price = 26

high = 9
low = 19

property_list = [[good, bad, normal_overall], # manual operation
                 [fit, small, big, normal_size],
                 [easy, difficult, normal_operation],
                 [yes, no, normal_compare],
                 [much, little, normal_degree],
                 [positive, negative, normal_experience],
                 [cheap, expensive, normal_price]]
cons = [high, low]  # manual operation


def str2variable(str_list):
    num_list = []
    for each_list in str_list:
        each = []
        for str in each_list:
            num = trans_number(str)
            each.append(num)
        num_list.append(each)

    return num_list


def trans_number(str): # manual operation
    if str == 'good':
        number = 0
    elif str == 'bad':
        number = 10
    elif str == 'normal_overall':
        number = 20

    elif str == 'fit':
        number = 1
    elif str == 'small':
        number = 11
    elif str == 'big':
        number = 21
    elif str == 'normal_size':
        number = 31

    elif str == 'easy':
        number = 2
    elif str == 'difficult':
        number = 12
    elif str == 'normal_operation':
        number = 22

    elif str == 'yes':
        number = 3
    elif str == 'no':
        number = 13
    elif str == '':
        number = 23

    elif str == 'much':
        number = 4
    elif str == 'little':
        number = 14
    elif str == 'normal_degree':
        number = 24

    elif str == 'positive':
        number = 5
    elif str == 'negative':
        number = 15
    elif str == 'normal_experience':
        number = 25

    elif str == 'cheap':
        number = 6
    elif str == 'expensive':
        number = 16
    elif str == 'normal_price':
        number = 26

    elif str == 'high':
        number = 9
    elif str == 'low':
        number = 19

    else:
        number = 100

    return number


input_path = "C:\\Users\\DELL\\Desktop\\Problem_C_Data\\microwave_property_normal.xlsx" # manual operation
trainSample = str2variable(reorder.excel2list(input_path))


def calc_entropy(list):
    entropy = 0
    total = 0

    for num in list:
        total += num

    for num in list:
        if num != 0:
            entropy -= Fraction(num, total) * math.log(Fraction(num, total), 2)
        else:
            entropy = entropy

    return entropy


def calc_gain_part(property_class_list):
    total = 0
    gain_part = 0
    for each_property_list in property_class_list:
        each_total = 0
        for num_cons in each_property_list:
            each_total += num_cons
        entropy = calc_entropy(each_property_list)
        gain_part += each_total * entropy
        total += each_total

    if total == 0:
        return 1000

    gain_part = gain_part/total
    return gain_part


def subset_judge(list, src):
    if set(list) <= set(src):
        return True
    else:
        return False


def tree(property_stack_list, property_list):
    property_num_list = [[[0, 0], [0, 0], [0, 0]], # manual operation
                         [[0, 0], [0, 0], [0, 0], [0, 0]],
                         [[0, 0], [0, 0], [0, 0]],
                         [[0, 0], [0, 0], [0, 0]],
                         [[0, 0], [0, 0], [0, 0]],
                         [[0, 0], [0, 0], [0, 0]],
                         [[0, 0], [0, 0], [0, 0]]]
    cons_num_list = [0, 0]

    branch_trainSample = []
    gain_list =[]

    for sample in trainSample:
        if subset_judge(property_stack_list, sample):
            branch_trainSample.append(sample)

    for each in branch_trainSample:
        if each[PROPERTY_NUM] == cons[0]:
            cons_num_list[0] += 1
        else:
            cons_num_list[1] += 1

    for train_list in branch_trainSample:
        for i in range(PROPERTY_NUM):
            j = int(train_list[i]/10)

            if j == 10:
                continue

            if train_list[PROPERTY_NUM] == cons[0]:
                property_num_list[i][j][0] = property_num_list[i][j][0] + 1 # pos
            else:
                property_num_list[i][j][1] = property_num_list[i][j][1] + 1 # neg

    entropy_s = calc_entropy(cons_num_list)
    if entropy_s == 0:
        if cons_num_list[0] > 0:
            print('--%s' % cons_name[0])
        else:
            print('--%s' % cons_name[1])
        return 0

    if len(property_stack_list) < PROPERTY_NUM:
        for i in range(len(property_num_list)):
            each_property_list = property_num_list[i]
            for stack in property_stack_list:
                if i == stack%10:
                    gain = 0
                    break
            else:
                gain_part = calc_gain_part(each_property_list)
                gain = entropy_s - gain_part
            gain_list.append(gain)
        # print(gain_list)

        max_flag = gain_list.index(max(gain_list))
        print('--%s' % property_name[max_flag].upper(), end= '')

        for i in range(len(property_list[max_flag])):
            property_stack_list.append(property_list[max_flag][i])
            print('--%s' % name[max_flag][i], end='')
            tree(property_stack_list, property_list)
            property_stack_list.pop()

    else:
        if cons_num_list[0] > cons_num_list[1]:
            print('--(more)%s' % cons_name[0])
        elif cons_num_list[0] < cons_num_list[1]:
            print('--(more)%s' % cons_name[1])
        else:
            print('--both')




if __name__ == '__main__':
    property_stack_list = []
    tree(property_stack_list, property_list)
    print('Finish!')