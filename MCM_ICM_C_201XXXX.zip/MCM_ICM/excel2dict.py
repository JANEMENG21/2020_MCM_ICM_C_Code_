import xlrd

class ReadEx():
    def read_excel(self, path):
        book = xlrd.open_workbook(path)
        table = book.sheet_by_name("pacifier")
        row_Num = table.nrows
        col_Num = table.ncols

        s =[]
        key =table.row_values(0)

        if row_Num <= 1:
            print("No data!")
        else:
            j = 1
            for i in range(row_Num-1):
                d ={}
                values = table.row_values(j)
                for x in range(col_Num):
                    d[key[x]]=values[x]
                j+=1
                s.append(d)
            return s

if __name__ == '__main__':
    r = ReadEx()
    path = "C:\\Users\\DELL\\Desktop\\Problem_C_Data\\try.xlsx"
    s = r.read_excel(path)
    for i in s:
        print(i)
    print(s)