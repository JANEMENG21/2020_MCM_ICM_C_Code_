import xlwt
import pandas as pd

def export_excel(list, path):
   workbook = xlwt.Workbook(encoding= 'utf-8')
   worksheet = workbook.add_sheet('sheet1')

   for i in range(len(list)):
       for j in range(len(list[i])):
           if j == len(list[i]):
               worksheet.write(i, j, str(list[i][j][0]) + '\n')
           else:
               worksheet.write(i, j, str(list[i][j][0]) + '\t')

   workbook.save(path)
   print('创建成功！')

if __name__ == '__main__':
    list = [[[1, 2]], [[3, 4]], [[5, 6]]]
    path = "C:\\Users\\DELL\\Desktop\\Problem_C_Data\\try1.xls"
    export_excel(list, path)
