import excel2dict
import list2excel
import nltk
import re

PATH = "C:\\Users\\DELL\\Desktop\\pacifier.xlsx"
src = excel2dict.ReadEx()
dict = src.read_excel(PATH)

tag_list = []
for item in dict:
    property_list = []
    # if item['star_rating'] > 2:
    text = item['review_body']
    FILTER = re.compile("[^a-z|^A-Z]+")
    text_list = FILTER.split(text)
    # text_list = re.sub("[^a-zA-Z]", " ", text).split()
    freq_dist = nltk.FreqDist(text_list)
    text_tag_list = nltk.tag.pos_tag(freq_dist.keys())
    # print(text_tag_list)
    tag_num = len(text_tag_list)
    for i in range(tag_num):
        if text_tag_list[i][1] == 'JJ' \
                or text_tag_list[i][1] == 'JJR' \
                or text_tag_list[i][1] == 'JJS':
            property_list.append([list(freq_dist.keys())[i], list(freq_dist.values())[i]])

    # print(property_list)
    tag_list.append(property_list)

path = "C:\\Users\\DELL\\Desktop\\pacifier_tag.xls"
list2excel.export_excel(tag_list, path)
print('Finish!')

