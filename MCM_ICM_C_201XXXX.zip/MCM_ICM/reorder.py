import xlwt
import xlrd

PROPERTY_NUM = 7
property_name = ['overall', 'size', 'operation', 'compare', 'degree', 'experience', 'price', 'rate']
overall = ['good', 'bad']
size = ['fit', 'small', 'big']
operation = ['easy', 'difficult']
compare = ['yes', 'no']
degree = ['much', 'little']
experience = ['positive', 'negative']
price = ['cheap', 'expensive']
rate = ['high', 'low']
property = [overall, size, operation, compare, degree, experience, price, rate]

# print(set(['good\t']) < set(overall))
def excel2list(path, sheet = "sheet1"):
    book = xlrd.open_workbook(path)
    table = book.sheet_by_name(sheet)
    row_Num = table.nrows
    col_Num = table.ncols

    s = []

    if row_Num <= 1:
        print("No data!")
    else:
        for i in range(row_Num):
            values = []
            for tag in table.row_values(i):
                if isinstance(tag, str):
                    values.append(tag.replace('\t', ''))
                else:
                    values.append(tag)
            s.append(values)
        return s


def pickout(list):
    aim_list = []
    for i in range(len(list)):
        each = ['NONE'] * (PROPERTY_NUM + 1)
        for each_tag in list[i]:
            if isinstance(each_tag, str):
                for j in range(len(property)):
                    if set([each_tag]) < set(property[j]):
                        each[j] = each_tag
                        break

            else:
                if each_tag > 2:
                    each[PROPERTY_NUM] = rate[0]
                else:
                    each[PROPERTY_NUM] = rate[1]

        if each[3] == 'NONE':
            each[3] = 'no'
        aim_list.append(each)

    return aim_list


def export_excel(list, path):
   workbook = xlwt.Workbook(encoding= 'utf-8')
   worksheet = workbook.add_sheet('sheet1')

   for i in range(len(list)):
       for j in range(len(list[i])):
           if j == len(list[i]):
               worksheet.write(i, j, str(list[i][j]) + '\n')
           else:
               worksheet.write(i, j, str(list[i][j]) + '\t')

   workbook.save(path)
   print('创建成功！')


def sequence(input_path, output_path):
    sequence_list = []
    sequence_list.append(property_name)

    tag_list = excel2list(input_path)
    tag_list = pickout(tag_list)
    sequence_list.extend(tag_list)
    export_excel(sequence_list, output_path)

    return sequence_list


if __name__ == '__main__':
    input_path = "C:\\Users\\DELL\\Desktop\\Problem_C_Data\\microwave_tag_1-2.xlsx"
    output_path = "C:\\Users\\DELL\\Desktop\\Problem_C_Data\\microwave_property_1-2.xls"
    sequence_list = sequence(input_path, output_path)
    # print(sequence_list)