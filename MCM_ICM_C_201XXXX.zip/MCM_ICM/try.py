import re
text = "sta tar 555 我还是Adoponwjevjbj"
FILTER = re.compile("[^a-z|^A-Z]+")
text_list = re.sub("[^a-zA-Z]", " ", text).split()
print(text_list)